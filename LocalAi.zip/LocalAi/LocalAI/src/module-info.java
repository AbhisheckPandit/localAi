module LocalAI {
	requires gson;
}